import os
import pandas as pd
import numpy as np
import copy

#functions------------------------------------------------------------
def listdir(d):
    return os.listdir(d)
def loadmodel(bacteria,dirlist):
    model_dic = {}
    for i in dirlist : 
        model = i.split('.')[0]
        if model == bacteria:
            modelfile = open(model_dir+i,'r')
            content = modelfile.read().strip(' \n').strip()
            content_list = content.split('=')[1].strip(' \n').rstrip('0').rstrip('-').split('\n')
            break
    for j in content_list:
        if '*' in j:
            j = j.strip().strip(' +').split('*')
            coefficient = float(j[0].strip())
            bacteria = j[1].strip()
            model_dic[bacteria] = coefficient
    return model_dic
#path-------------------------------------------------------------
model_dir = './weka/'
dirlist = listdir(model_dir)
otu_dir = './otu/'
month = 7
month_name = otu_dir + 'ratio' + str(month) + '.csv'
otu_file = pd.read_csv(month_name,header = None)
def counteven(lastmatix):
    val = lastmatix[1]
    nl = []
    for i in val : 
        if i > 0:
            nl.append(np.log(i)) 
    cross = []
    for j in range(len(nl)) :
        cross.append(val[j] * nl[j])
    sumeven = -(np.array(cross).sum())
    return sumeven


def sortbyvalue(promatrix):
    label = promatrix[0]
    val = promatrix[1]
    newma = [[],[]]
    dic = {}
    for i in range(len(val)): 
        dic[val[i]] = i
    dic = dict(sorted(dic.items(),reverse=True))
    for k,v in dic.items():
        newma[0].append(label[v])
        newma[1].append(k)
    return newma

def makeperent(otumatrix):
    otumatrix = np.array(otumatrix)
    otumatrix = np.delete(otumatrix, np.s_[-1], axis=1)
    otumatrix = np.delete(otumatrix, np.s_[-1], axis=1)
    otumatrix = np.delete(otumatrix, np.s_[-1], axis=1)
    bacteria_list = otumatrix[0]
    columnlen = len(bacteria_list)
    new = []
    for i in range(1,len(otumatrix)):
        new.append([])
        for j in range(1,columnlen):
            lsum = np.array([float(x) for x in list(otumatrix[i][1::])])
            new[i-1].append(float(otumatrix[i][j])/np.sum(lsum))
    for k in new : 
        if np.isnan(k[0]):
            new.remove(k)
    new = [list(np.array(new).sum(axis=0))]
    new2 = [[]]
    for l in new[0]:
        lsum = np.array(new[0])
        new2[0].append(l/np.sum(lsum))
    return new2

def default():
    otu_file1 = copy.deepcopy(otu_file)
    otu_file3 = otu_file1.as_matrix()
    ma = makeperent(otu_file3)
    malen = len(ma[0])
    label = otu_file3[0][1:malen+1]
    ma.insert(0,label)
    fn = sortbyvalue(ma)
    eveness = counteven(fn)
    df = pd.DataFrame(fn)
    return df, eveness
def afterbutton(n,p,k):
    otu_file2 = copy.deepcopy(otu_file)
    otu_file2 = otu_file2.as_matrix()
    for i in range(1,len(otu_file2)):
        for j in range(len(otu_file2[0])):
            print('looping')
            if j == 701:
                print('n yes')
                otu_file2[i][j] = n
            elif j == 702:
                print('p yes')
                otu_file2[i][j] = p
            elif j == 703:
                print('k yes')
                otu_file2[i][j] = k
    result = []
    bacteria_list = otu_file2[0]
    list_len = len(bacteria_list)
    for row in range(1,len(otu_file2)):
        result.append([otu_file2[row][0]])
        for column in range(1,list_len):
            print('row',row,'column',column)
            ans = 0
            result[row-1].append(ans)
            if otu_file2[0][column]+'.txt' in dirlist:
                model = loadmodel(otu_file2[0][column],dirlist)
                otu_value = float(otu_file2[row][column])
                for k,v in model.items():
                    for l in range(1,len(otu_file2[row])):
                        if k == otu_file2[0][l]:
                            ans += otu_value * v
            result[row-1][column] += ans
    result.insert(0,bacteria_list)
    ma = makeperent(result)
    malen = len(ma[0])
    label = result[0][1:malen+1]
    ma.insert(0,label)
    fn = sortbyvalue(ma)
    eveness = counteven(fn)
    df = pd.DataFrame(fn)
    return df, eveness