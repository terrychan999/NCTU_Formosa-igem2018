import cherrypy
import os, os.path
import pandas as pd
import test as ts
import numpy as np

header = '''
  <meta charset="UTF-8">
  <title>Microbiota Prediction</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="jQueryAssets/jquery-1.11.1.min.js"></script>
  <script src="jQueryAssets/jquery.ui-1.10.4.dialog.min.js"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />
  <link rel="Shortcut Icon" type="image/x-icon" href="website.png">
  <style>
    @font-face{
	font-family: solaris;
        src : url("Solaris.ttf");
    }
    @font-face{
	font-family : Levenim MT;
	src : url("lvnm.ttf");
    }

    #globalWrapper{
      padding-bottom: 0 !important;
    }

    body{
      font-size: 0;
      margin: 0;
      padding: 0 !important;
      width: 100%;
      overflow-y: auto;
    }

    .wrapper{
      width: 100%;
      background-image: url("bgi.png");
      background-size: cover;
      font-family: Levenim MT;
      position: relative;
      padding-bottom: 10vw;
    }

    .plogo{
      display: inline-block;
      width: 15%;
      margin-left: 5%;
      margin-top: 5vw;
      vertical-align: sup;
    }

    .title{
      font-size: 6vw;
      margin-top: 3vw;
      margin-bottom: 3vw;
      margin-left: 3%;
      text-align: left;
      color: white;
      position: relative;
      top: -3vw;
      font-family: solaris;
      display: inline-block;
    }

    .title_1{
      font-size: 6vmin;
      width: 75%;
      margin: 50px;
      margin-top: 100px;
      margin-left: 12.5%;
    }

    .title_2{
      font-size: 5vmin;
      width: 70%;
      margin: 50px;
      margin-left: 15%;
    }

    .title_3{
      font-size: 3.5vmin;
      width: 70%;
      margin: 50px;
      margin-left: 15%;
    }

    .text{
      font-size: 3vmin;
      width: 75%;
      position: relative;
      margin-left: 12.5%;
      margin-right: 12.5%;
      margin-top: 40px;
      margin-bottom: 40px;
      text-align: justify;
      color: white;
    }

    .explanation{
      font-size: 2.5vmin;
      font-weight: bold;
      color: #575656;
      text-align: center;
    }

    p{
      margin: 0;
    }

    table{
      width: 55%;
      border: solid 2px #e7eceb;
      text-align: left;
      margin: 40px;
      margin-left: auto;
      margin-right: auto;
      padding: 10px;
      border-collapse: collapse;
      background: #fefefe;
    }

    tr{
      border: solid 1px #e7eceb;
      margin: 15px;
      padding: 10px;
    }

    td,th{
      hight : 50px;
      width : auto;
      text-align : center;
    }

    caption{
      font-size: 3vmin;
      font-weight: bold;
      margin-bottom: 10px;
      color: #575656;
      box-sizing: border-box;
    }

    thead{
      background: #1182be;
      color: #fefefe;
      font-size: 3.5vmin;
    }

    tbody{
      font-size: 3vmin;
    }

    .equation{
      font-size: 3vmin;
      margin: 40px;
      text-align: center;
      margin-left: auto;
      margin-right: auto;
    }

    .icon{
      width: 20px;
      vertical-align: middle;
    }

    .pic{
      width: 100%;
    }

    .procedure{
      width: 100px;
    }

    .bar{
      width: 100%;
      margin-top: 5vw;
      margin-bottom: 5vw;
    }

    .input{
      display: inline-block;
      width: 32%;
      transition-duration: 0.4s;
      cursor: pointer;
    }

    .input:hover{
    }

    .arrow{
      display: inline-block;
      width: 10%;
      position: relative;
      top: 0.4vw;
    }

    .result{
      display: inline-block;
      width: 58%;
      transition-duration: 0.4s;
      cursor: pointer;
    }

    .result:hover{
    }

    .button{
      width: 15%;
      position: relative;
      display: inline-block;
      margin-left: 13.75%;
      margin-top: 1vw;
    }

    .value{
      margin-left: 13.75%;
      font-size: 2vw;
      height: 3vw;
      width: 15%;
      position: relative;
      top: -2.6vw;
      padding-left: 1vw;
      border-radius: 0.5vw;
    }

    .click{
      width: 30%;
      font-size: 2.5vw;
      border-radius: 1vw;
      padding: 1vw;
      padding-left: 2vw;
      padding-right: 2vw;
      margin-left: 53%;
      margin-top: 3vw;
      cursor: pointer;
      transition-duration: 0.3s;
      background-color: #0b1147;
      color: white;
      border: 0px;
    }

    .click:hover{
      color: rgb(27, 189, 190);
    }

    .left{
      margin-top : 50px;
      width: 100%;
      display: inline-block;
    }

    .right{
      width: 60%;
      display: inline-block;
    }

    .unit{
      font-family: solaris;
      font-size: 2.5vw;
      margin-left: 13.75%;
      color: white;
      width: 15%;
      display: inline-block;
      position: relative;
      top: -2.5vw;
    }

    .right{
      display: inline-block;
      width: 100%;
    }
    .otu{
      width : 45%;
      display : inline-block;
      margin-left : 10%;
    }
    .otublock{
      display: inline-block;
      width: 80%;
      overflow-x : auto;
      margin-left : 10%;
      
    }
    .dataframe{
      text-align : center;
      margin-top : 10px;
    }
    .pieblock{
      display: inline-block;
      width: 60%;
    }
    .pie{
      width: 60%;
    }
    .evenessblock{
      width: 100%;
    }
    .eveness{
      margin-top : 50px;
      width : 45%;
      display : inline-block;
      margin-left : 10%;
    }
    .july{
      margin-bottom : 0;
    }
    .preotu{
      margin-bottom : 0;
    }


  </style>

  <!----------------------------------------------------------------------------->

  <script>
  </script>

  <!----------------------------------------------------------------------------->

  <!-- Latex resourse code-->
  <script src="http://cdn.mathjax.org/mathjax/latest/MathJax.js" type="text/javascript">
      MathJax.Hub.Config({
          extensions: ["tex2jax.js", "TeX/AMSmath.js", "TeX/AMSsymbols.js"],
          jax: ["input/TeX", "output/HTML-CSS"],
          tex2jax: {
              inlineMath: [
                  ['$', '$'],
                  ["\\(", "\\)"]
              ],
              displayMath: [
                  ['$$', '$$'],
                  ["\\[", "\\]"]
              ],
          },
          "HTML-CSS": {
              availableFonts: ["TeX"]
          }
      });
  </script>

'''
bodya ='''
  <div class="wrapper">
      <img src='PL.png' class="plogo">
      <div class="title"><p>MicrObiOtA PrEdictiOn</p></div>
      <div class="text">
        <p>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Fertilization of soil is the backbone of modern agriculture. As the global population continues to skyrocket, so too must the productivity of farms across the world to keep up with demand. Aggressive use of fertilizers to increase the core nutrients in soil – nitrogen, phosphorus and potassium – has proved to be vital in maintaining high agricultural output. However, the application of fertilizers is anything but precise – farmers often rely on experience rather than raw data to decide when and what to use. The uncontrolled addition of these often chemical-based nutrients results in skewed bacterial distribution, causing numerous problems such as acidification and salinization, ultimately catalyzing the erosion of soil. If fertilization remains unregulated, damage to soil integrity will devastate not only the agriculture industry but also the entire human population.
        </p>
      </div>
      <div class="bar">
        <img src='Input_1.png' class="input">
        <img src="Arrow3.png" class="arrow">
        <img src="Results.png" class="result">
      </div>
      <img src="N.png" class="button n">
      <img src="P.png" class="button p">
      <img src='K.png' class="button k">
      <div class="left">
      <form method="get" action="get_value">
        <input type="text" name='n' class="value" width="20%" placeholder="1~25">
        <input type="text" name='k' class="value" width="20%" placeholder="1~25">        
        <input type="text" name='p' class="value" width="20%" placeholder="1~25">
        <div class="unit">kG/hA</div>
        <div class="unit">kG/hA</div>
        <div class="unit">kG/hA</div>
        <input type="submit" class="click" value="Predict">
      </form>
      </div>
      <div class="right">
          <img src='otu.png' class="otu">
'''
bodyc = '''
        <div class='text july'><p>July Real Microbiota Proportion</p></div>
        <div class="otublock">
'''
bodyd ='''
        <div class='text preotu'><p>Predicted Microbiota Proportion After Fertilized</p></div>
        <div class="otublock">
'''

bodyb = '''
        </div>
          <img src="eveness.png" class="eveness">
        <div class="evenessblock">
          <div class="text evenessdata"><p>Shannon Index : 
'''
bodye = '''
          </p></div>
        </div>
      </div>
  </div>
'''

def bepercentage(otudata):
  otudata = otudata.as_matrix()
  label = otudata[0]
  val = otudata[1]
  new = [label,[]]
  for i in val:
    b = round(float(i)*100,2)
    new[1].append(str(b)+'%')
  return(new)

class Web(object):
    @cherrypy.expose
    def index(self):
      otudata, eveness = ts.default()
      eveness = round(eveness, 2)
      otudata = pd.DataFrame(bepercentage(otudata))
      otudata = str(otudata.to_html(header=False,index=False))
      return header + bodya + bodyc + otudata + bodyb + str(eveness) + bodye
    @cherrypy.expose
    def get_value(self, n,p,k):
      otudata, eveness = ts.afterbutton(n,p,k)
      eveness = round(eveness, 2)
      otudata = pd.DataFrame(bepercentage(otudata))
      otudata = str(otudata.to_html(header=False,index=False))
      return header + bodya + bodyd + otudata + bodyb + str(eveness) + bodye


if __name__ == '__main__':
  cherrypy.config.update({'server.socket_port': 80})
  cherrypy.quickstart(Web() ,config="config.txt")
    
